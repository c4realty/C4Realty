// En el panel de C4 Realty: avisa que la extensión está instalada y guarda la imagen y el texto que se van a mandar.
document.documentElement.dataset.c4WaExt = "1";
window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.tipo !== "C4_WA_ENVIAR") return;
  const { img, texto, directo } = e.data;
  if (typeof img !== "string" || !img.startsWith("data:image/")) return;
  chrome.storage.local.set({ c4pendiente: { img, texto: String(texto || "").slice(0, 4000), directo: !!directo, t: Date.now() } }, () => {
    window.postMessage({ tipo: "C4_WA_LISTO" }, "*");
  });
});
